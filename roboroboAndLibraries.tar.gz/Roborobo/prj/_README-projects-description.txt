=-=
=-= PRJ DIRECTORY CONTENT DESCRIPTION
=-=

Please fill in the project name/location, correspondant(s), starting date and short description for each projects in this directory. Please update if required.

[REVERSE CHRONOLOGICAL ORDER]

mEDEA-ecology
  - started: june 2012
  - correspondant: Nicolas Bredeche
  - medea and environment / ecological project

mEDEA-pheromones
  - started: june 2012
  - correspondant: Nicolas Bredeche
  - experimenting medea with pheromones
    
mEDEA-HGT
  - started: end 2011
  - correspondant: Leo Cazenille
  - Horizontal Gene Transfer variation operator in medea

mEDEA-comm
  - started: end 2011
  - correspondant: JM Montanier
  - medea and communication
   
mEDEA-sp
mEDEA-specialize
mEDEA-MovingSp
  - started: early 2011
  - correspondant: Simon Carrignon
  - speciation with medea

mEDEA-optim
  - started: early 2011
  - correspondant: Nicolas Bredeche / Leo Cazenille
  - mixing medea and optimization (embodied evolution)

SpikeAnts
  - started: early 2011
  - correspondant: Sylvain Chevallier
  - Swarm synchronization with spiking neurons (chech ECAL 2011b)

mEDEA-altruism
mEDEA-altruism-utility
  - started: end 2010
  - original author: JM Montanier
  - medea with altruism (check ECAL 2011)

mEDEA-twosuns
  - started: mid 2010
  - correspondant: Nicolas Bredeche

OnePlusOne-Online
  - started: early 2009
  - correspondant: Nicolas Bredeche
  - (1+1)-online adaptation, testing strong causality (check EA 2009)

BasicProject
 - started: end 2009
 - correspondant: Nicolas Bredeche
 - basic demonstration with one wandering robot

BasicProject-mEDEA
  - started: end 2009
  - correspondants: Nicolas Bredeche / JM Montanier
  - basic medea algorithm

mEDEA
  - started: end 2009
  - correspondant: Nicolas Bredeche / JM Montanier
  - first implementation (check PPSN 2010, MCMDS 2012)
