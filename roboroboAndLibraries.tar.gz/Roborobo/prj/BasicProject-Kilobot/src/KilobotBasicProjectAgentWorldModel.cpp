/*
 *  KilobotBasicWorldModel.cpp
 *  roborobo-online
 *
 *  Created by Nicolas on 27/05/10.
 *
 */

#include "BasicProject-Kilobot/include/KilobotBasicProjectAgentWorldModel.h"

#include "World/World.h"

KilobotBasicAgentWorldModel::KilobotBasicAgentWorldModel()
{
	_sensors = NULL;
}

KilobotBasicAgentWorldModel::~KilobotBasicAgentWorldModel()
{
	if ( _sensors != NULL )
		delete[] _sensors;
}
