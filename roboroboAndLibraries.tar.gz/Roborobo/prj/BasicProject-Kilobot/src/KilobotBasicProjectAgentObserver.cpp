/*
 *  KilobotBasicAgentObserver.cpp
 *  roborobo-online
 *
 *  Created by Nicolas on 27/05/10.
 *
 */

#include "BasicProject-Kilobot/include/KilobotBasicProjectAgentObserver.h"



KilobotBasicAgentObserver::KilobotBasicAgentObserver( )
{
}

KilobotBasicAgentObserver::KilobotBasicAgentObserver( RobotAgentWorldModel *__wm )
{
	_wm = (KilobotBasicAgentWorldModel*)__wm;
}

KilobotBasicAgentObserver::~KilobotBasicAgentObserver()
{
	// nothing to do.
}

void KilobotBasicAgentObserver::reset()
{
	// nothing to do.
}

void KilobotBasicAgentObserver::step()
{
	// nothing to do.
}

