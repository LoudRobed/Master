/*
 *  KilobotBasicWorldObserver.cpp
 *  roborobo-online
 *
 *  Created by Nicolas on 27/05/10.
 *
 */

#include "BasicProject-Kilobot/include/KilobotBasicProjectWorldObserver.h"

#include "World/World.h"


KilobotBasicWorldObserver::KilobotBasicWorldObserver( World *__world ) : WorldObserver( __world )
{
	_world = __world;
}

KilobotBasicWorldObserver::~KilobotBasicWorldObserver()
{
	// nothing to do.
}

void KilobotBasicWorldObserver::reset()
{
	// nothing to do.
}

void KilobotBasicWorldObserver::step()
{
	// nothing to do.
}


