/*
 *  KilobotBasicWorldObserver.h
 *  roborobo-online
 *
 *  Created by Nicolas on 27/05/10.
 *
 */



#ifndef KILOBOTBASICWORLDOBSERVER_H
#define KILOBOTBASICWORLDOBSERVER_H

#include "RoboroboMain/common.h"
#include "RoboroboMain/roborobo.h"

#include "Observers/WorldObserver.h"

class World;

class KilobotBasicWorldObserver : public WorldObserver
{
	protected:
		
	public:
		KilobotBasicWorldObserver( World *__world );
		~KilobotBasicWorldObserver();
				
		void reset();
		void step();
		
};

#endif

