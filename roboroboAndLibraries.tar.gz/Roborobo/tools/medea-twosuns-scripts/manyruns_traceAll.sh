./manyruns_traceDistance.sh $1
./manyruns_traceOrientation.sh $1
