./monorun_traceDistance.sh $1
./monorun_traceOrientation.sh $1
