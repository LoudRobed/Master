./roborobo -l config/config_10_16.properties
mkdir logs/exp_10_16
mv logs/datalog* logs/exp_10_16/
mv logs/properties* logs/exp_10_16/
mv logs/screenshot* logs/exp_10_16/
./roborobo -l config/config_10_32.properties
mkdir logs/exp_10_32
mv logs/datalog* logs/exp_10_32/
mv logs/properties* logs/exp_10_32/
mv logs/screenshot* logs/exp_10_32/
./roborobo -l config/config_10_64.properties
mkdir logs/exp_10_64
mv logs/datalog* logs/exp_10_64/
mv logs/properties* logs/exp_10_64/
mv logs/screenshot* logs/exp_10_64/
./roborobo -l config/config_11_16.properties
mkdir logs/exp_11_16
mv logs/datalog* logs/exp_11_16/
mv logs/properties* logs/exp_11_16/
mv logs/screenshot* logs/exp_11_16/
./roborobo -l config/config_11_32.properties
mkdir logs/exp_11_32
mv logs/datalog* logs/exp_11_32/
mv logs/properties* logs/exp_11_32/
mv logs/screenshot* logs/exp_11_32/
./roborobo -l config/config_11_64.properties
mkdir logs/exp_11_64
mv logs/datalog* logs/exp_11_64/
mv logs/properties* logs/exp_11_64/
mv logs/screenshot* logs/exp_11_64/
./roborobo -l config/config_12_16.properties
mkdir logs/exp_12_16
mv logs/datalog* logs/exp_12_16/
mv logs/properties* logs/exp_12_16/
mv logs/screenshot* logs/exp_12_16/
./roborobo -l config/config_12_32.properties
mkdir logs/exp_12_32
mv logs/datalog* logs/exp_12_32/
mv logs/properties* logs/exp_12_32/
mv logs/screenshot* logs/exp_12_32/
./roborobo -l config/config_12_64.properties
mkdir logs/exp_12_64
mv logs/datalog* logs/exp_12_64/
mv logs/properties* logs/exp_12_64/
mv logs/screenshot* logs/exp_12_64/
./roborobo -l config/config_13_16.properties
mkdir logs/exp_13_16
mv logs/datalog* logs/exp_13_16/
mv logs/properties* logs/exp_13_16/
mv logs/screenshot* logs/exp_13_16/
./roborobo -l config/config_13_32.properties
mkdir logs/exp_13_32
mv logs/datalog* logs/exp_13_32/
mv logs/properties* logs/exp_13_32/
mv logs/screenshot* logs/exp_13_32/
./roborobo -l config/config_13_64.properties
mkdir logs/exp_13_64
mv logs/datalog* logs/exp_13_64/
mv logs/properties* logs/exp_13_64/
mv logs/screenshot* logs/exp_13_64/
./roborobo -l config/config_14_16.properties
mkdir logs/exp_14_16
mv logs/datalog* logs/exp_14_16/
mv logs/properties* logs/exp_14_16/
mv logs/screenshot* logs/exp_14_16/
./roborobo -l config/config_14_32.properties
mkdir logs/exp_14_32
mv logs/datalog* logs/exp_14_32/
mv logs/properties* logs/exp_14_32/
mv logs/screenshot* logs/exp_14_32/
./roborobo -l config/config_14_64.properties
mkdir logs/exp_14_64
mv logs/datalog* logs/exp_14_64/
mv logs/properties* logs/exp_14_64/
mv logs/screenshot* logs/exp_14_64/
./roborobo -l config/config_15_16.properties
mkdir logs/exp_15_16
mv logs/datalog* logs/exp_15_16/
mv logs/properties* logs/exp_15_16/
mv logs/screenshot* logs/exp_15_16/
./roborobo -l config/config_15_32.properties
mkdir logs/exp_15_32
mv logs/datalog* logs/exp_15_32/
mv logs/properties* logs/exp_15_32/
mv logs/screenshot* logs/exp_15_32/
./roborobo -l config/config_15_64.properties
mkdir logs/exp_15_64
mv logs/datalog* logs/exp_15_64/
mv logs/properties* logs/exp_15_64/
mv logs/screenshot* logs/exp_15_64/
./roborobo -l config/config_16_16.properties
mkdir logs/exp_16_16
mv logs/datalog* logs/exp_16_16/
mv logs/properties* logs/exp_16_16/
mv logs/screenshot* logs/exp_16_16/
./roborobo -l config/config_16_32.properties
mkdir logs/exp_16_32
mv logs/datalog* logs/exp_16_32/
mv logs/properties* logs/exp_16_32/
mv logs/screenshot* logs/exp_16_32/
./roborobo -l config/config_16_64.properties
mkdir logs/exp_16_64
mv logs/datalog* logs/exp_16_64/
mv logs/properties* logs/exp_16_64/
mv logs/screenshot* logs/exp_16_64/
./roborobo -l config/config_17_16.properties
mkdir logs/exp_17_16
mv logs/datalog* logs/exp_17_16/
mv logs/properties* logs/exp_17_16/
mv logs/screenshot* logs/exp_17_16/
./roborobo -l config/config_17_32.properties
mkdir logs/exp_17_32
mv logs/datalog* logs/exp_17_32/
mv logs/properties* logs/exp_17_32/
mv logs/screenshot* logs/exp_17_32/
./roborobo -l config/config_17_64.properties
mkdir logs/exp_17_64
mv logs/datalog* logs/exp_17_64/
mv logs/properties* logs/exp_17_64/
mv logs/screenshot* logs/exp_17_64/
./roborobo -l config/config_18_16.properties
mkdir logs/exp_18_16
mv logs/datalog* logs/exp_18_16/
mv logs/properties* logs/exp_18_16/
mv logs/screenshot* logs/exp_18_16/
./roborobo -l config/config_18_32.properties
mkdir logs/exp_18_32
mv logs/datalog* logs/exp_18_32/
mv logs/properties* logs/exp_18_32/
mv logs/screenshot* logs/exp_18_32/
./roborobo -l config/config_18_64.properties
mkdir logs/exp_18_64
mv logs/datalog* logs/exp_18_64/
mv logs/properties* logs/exp_18_64/
mv logs/screenshot* logs/exp_18_64/
./roborobo -l config/config_19_16.properties
mkdir logs/exp_19_16
mv logs/datalog* logs/exp_19_16/
mv logs/properties* logs/exp_19_16/
mv logs/screenshot* logs/exp_19_16/
./roborobo -l config/config_19_32.properties
mkdir logs/exp_19_32
mv logs/datalog* logs/exp_19_32/
mv logs/properties* logs/exp_19_32/
mv logs/screenshot* logs/exp_19_32/
./roborobo -l config/config_19_64.properties
mkdir logs/exp_19_64
mv logs/datalog* logs/exp_19_64/
mv logs/properties* logs/exp_19_64/
mv logs/screenshot* logs/exp_19_64/
./roborobo -l config/config_20_16.properties
mkdir logs/exp_20_16
mv logs/datalog* logs/exp_20_16/
mv logs/properties* logs/exp_20_16/
mv logs/screenshot* logs/exp_20_16/
./roborobo -l config/config_20_32.properties
mkdir logs/exp_20_32
mv logs/datalog* logs/exp_20_32/
mv logs/properties* logs/exp_20_32/
mv logs/screenshot* logs/exp_20_32/
./roborobo -l config/config_20_64.properties
mkdir logs/exp_20_64
mv logs/datalog* logs/exp_20_64/
mv logs/properties* logs/exp_20_64/
mv logs/screenshot* logs/exp_20_64/
./roborobo -l config/config_21_16.properties
mkdir logs/exp_21_16
mv logs/datalog* logs/exp_21_16/
mv logs/properties* logs/exp_21_16/
mv logs/screenshot* logs/exp_21_16/
./roborobo -l config/config_21_32.properties
mkdir logs/exp_21_32
mv logs/datalog* logs/exp_21_32/
mv logs/properties* logs/exp_21_32/
mv logs/screenshot* logs/exp_21_32/
./roborobo -l config/config_21_64.properties
mkdir logs/exp_21_64
mv logs/datalog* logs/exp_21_64/
mv logs/properties* logs/exp_21_64/
mv logs/screenshot* logs/exp_21_64/
./roborobo -l config/config_22_16.properties
mkdir logs/exp_22_16
mv logs/datalog* logs/exp_22_16/
mv logs/properties* logs/exp_22_16/
mv logs/screenshot* logs/exp_22_16/
./roborobo -l config/config_22_32.properties
mkdir logs/exp_22_32
mv logs/datalog* logs/exp_22_32/
mv logs/properties* logs/exp_22_32/
mv logs/screenshot* logs/exp_22_32/
./roborobo -l config/config_22_64.properties
mkdir logs/exp_22_64
mv logs/datalog* logs/exp_22_64/
mv logs/properties* logs/exp_22_64/
mv logs/screenshot* logs/exp_22_64/
./roborobo -l config/config_23_16.properties
mkdir logs/exp_23_16
mv logs/datalog* logs/exp_23_16/
mv logs/properties* logs/exp_23_16/
mv logs/screenshot* logs/exp_23_16/
./roborobo -l config/config_23_32.properties
mkdir logs/exp_23_32
mv logs/datalog* logs/exp_23_32/
mv logs/properties* logs/exp_23_32/
mv logs/screenshot* logs/exp_23_32/
./roborobo -l config/config_23_64.properties
mkdir logs/exp_23_64
mv logs/datalog* logs/exp_23_64/
mv logs/properties* logs/exp_23_64/
mv logs/screenshot* logs/exp_23_64/
./roborobo -l config/config_24_16.properties
mkdir logs/exp_24_16
mv logs/datalog* logs/exp_24_16/
mv logs/properties* logs/exp_24_16/
mv logs/screenshot* logs/exp_24_16/
./roborobo -l config/config_24_32.properties
mkdir logs/exp_24_32
mv logs/datalog* logs/exp_24_32/
mv logs/properties* logs/exp_24_32/
mv logs/screenshot* logs/exp_24_32/
./roborobo -l config/config_24_64.properties
mkdir logs/exp_24_64
mv logs/datalog* logs/exp_24_64/
mv logs/properties* logs/exp_24_64/
mv logs/screenshot* logs/exp_24_64/
./roborobo -l config/config_25_16.properties
mkdir logs/exp_25_16
mv logs/datalog* logs/exp_25_16/
mv logs/properties* logs/exp_25_16/
mv logs/screenshot* logs/exp_25_16/
./roborobo -l config/config_25_32.properties
mkdir logs/exp_25_32
mv logs/datalog* logs/exp_25_32/
mv logs/properties* logs/exp_25_32/
mv logs/screenshot* logs/exp_25_32/
./roborobo -l config/config_25_64.properties
mkdir logs/exp_25_64
mv logs/datalog* logs/exp_25_64/
mv logs/properties* logs/exp_25_64/
mv logs/screenshot* logs/exp_25_64/
./roborobo -l config/config_26_16.properties
mkdir logs/exp_26_16
mv logs/datalog* logs/exp_26_16/
mv logs/properties* logs/exp_26_16/
mv logs/screenshot* logs/exp_26_16/
./roborobo -l config/config_26_32.properties
mkdir logs/exp_26_32
mv logs/datalog* logs/exp_26_32/
mv logs/properties* logs/exp_26_32/
mv logs/screenshot* logs/exp_26_32/
./roborobo -l config/config_26_64.properties
mkdir logs/exp_26_64
mv logs/datalog* logs/exp_26_64/
mv logs/properties* logs/exp_26_64/
mv logs/screenshot* logs/exp_26_64/
./roborobo -l config/config_27_16.properties
mkdir logs/exp_27_16
mv logs/datalog* logs/exp_27_16/
mv logs/properties* logs/exp_27_16/
mv logs/screenshot* logs/exp_27_16/
./roborobo -l config/config_27_32.properties
mkdir logs/exp_27_32
mv logs/datalog* logs/exp_27_32/
mv logs/properties* logs/exp_27_32/
mv logs/screenshot* logs/exp_27_32/
./roborobo -l config/config_27_64.properties
mkdir logs/exp_27_64
mv logs/datalog* logs/exp_27_64/
mv logs/properties* logs/exp_27_64/
mv logs/screenshot* logs/exp_27_64/
./roborobo -l config/config_28_16.properties
mkdir logs/exp_28_16
mv logs/datalog* logs/exp_28_16/
mv logs/properties* logs/exp_28_16/
mv logs/screenshot* logs/exp_28_16/
./roborobo -l config/config_28_32.properties
mkdir logs/exp_28_32
mv logs/datalog* logs/exp_28_32/
mv logs/properties* logs/exp_28_32/
mv logs/screenshot* logs/exp_28_32/
./roborobo -l config/config_28_64.properties
mkdir logs/exp_28_64
mv logs/datalog* logs/exp_28_64/
mv logs/properties* logs/exp_28_64/
mv logs/screenshot* logs/exp_28_64/
./roborobo -l config/config_29_16.properties
mkdir logs/exp_29_16
mv logs/datalog* logs/exp_29_16/
mv logs/properties* logs/exp_29_16/
mv logs/screenshot* logs/exp_29_16/
./roborobo -l config/config_29_32.properties
mkdir logs/exp_29_32
mv logs/datalog* logs/exp_29_32/
mv logs/properties* logs/exp_29_32/
mv logs/screenshot* logs/exp_29_32/
./roborobo -l config/config_29_64.properties
mkdir logs/exp_29_64
mv logs/datalog* logs/exp_29_64/
mv logs/properties* logs/exp_29_64/
mv logs/screenshot* logs/exp_29_64/
./roborobo -l config/config_30_16.properties
mkdir logs/exp_30_16
mv logs/datalog* logs/exp_30_16/
mv logs/properties* logs/exp_30_16/
mv logs/screenshot* logs/exp_30_16/
./roborobo -l config/config_30_32.properties
mkdir logs/exp_30_32
mv logs/datalog* logs/exp_30_32/
mv logs/properties* logs/exp_30_32/
mv logs/screenshot* logs/exp_30_32/
./roborobo -l config/config_30_64.properties
mkdir logs/exp_30_64
mv logs/datalog* logs/exp_30_64/
mv logs/properties* logs/exp_30_64/
mv logs/screenshot* logs/exp_30_64/
./roborobo -l config/config_31_16.properties
mkdir logs/exp_31_16
mv logs/datalog* logs/exp_31_16/
mv logs/properties* logs/exp_31_16/
mv logs/screenshot* logs/exp_31_16/
./roborobo -l config/config_31_32.properties
mkdir logs/exp_31_32
mv logs/datalog* logs/exp_31_32/
mv logs/properties* logs/exp_31_32/
mv logs/screenshot* logs/exp_31_32/
./roborobo -l config/config_31_64.properties
mkdir logs/exp_31_64
mv logs/datalog* logs/exp_31_64/
mv logs/properties* logs/exp_31_64/
mv logs/screenshot* logs/exp_31_64/
./roborobo -l config/config_32_16.properties
mkdir logs/exp_32_16
mv logs/datalog* logs/exp_32_16/
mv logs/properties* logs/exp_32_16/
mv logs/screenshot* logs/exp_32_16/
./roborobo -l config/config_32_32.properties
mkdir logs/exp_32_32
mv logs/datalog* logs/exp_32_32/
mv logs/properties* logs/exp_32_32/
mv logs/screenshot* logs/exp_32_32/
./roborobo -l config/config_32_64.properties
mkdir logs/exp_32_64
mv logs/datalog* logs/exp_32_64/
mv logs/properties* logs/exp_32_64/
mv logs/screenshot* logs/exp_32_64/
./roborobo -l config/config_33_16.properties
mkdir logs/exp_33_16
mv logs/datalog* logs/exp_33_16/
mv logs/properties* logs/exp_33_16/
mv logs/screenshot* logs/exp_33_16/
./roborobo -l config/config_33_32.properties
mkdir logs/exp_33_32
mv logs/datalog* logs/exp_33_32/
mv logs/properties* logs/exp_33_32/
mv logs/screenshot* logs/exp_33_32/
./roborobo -l config/config_33_64.properties
mkdir logs/exp_33_64
mv logs/datalog* logs/exp_33_64/
mv logs/properties* logs/exp_33_64/
mv logs/screenshot* logs/exp_33_64/
./roborobo -l config/config_34_16.properties
mkdir logs/exp_34_16
mv logs/datalog* logs/exp_34_16/
mv logs/properties* logs/exp_34_16/
mv logs/screenshot* logs/exp_34_16/
./roborobo -l config/config_34_32.properties
mkdir logs/exp_34_32
mv logs/datalog* logs/exp_34_32/
mv logs/properties* logs/exp_34_32/
mv logs/screenshot* logs/exp_34_32/
./roborobo -l config/config_34_64.properties
mkdir logs/exp_34_64
mv logs/datalog* logs/exp_34_64/
mv logs/properties* logs/exp_34_64/
mv logs/screenshot* logs/exp_34_64/
./roborobo -l config/config_35_16.properties
mkdir logs/exp_35_16
mv logs/datalog* logs/exp_35_16/
mv logs/properties* logs/exp_35_16/
mv logs/screenshot* logs/exp_35_16/
./roborobo -l config/config_35_32.properties
mkdir logs/exp_35_32
mv logs/datalog* logs/exp_35_32/
mv logs/properties* logs/exp_35_32/
mv logs/screenshot* logs/exp_35_32/
./roborobo -l config/config_35_64.properties
mkdir logs/exp_35_64
mv logs/datalog* logs/exp_35_64/
mv logs/properties* logs/exp_35_64/
mv logs/screenshot* logs/exp_35_64/
./roborobo -l config/config_36_16.properties
mkdir logs/exp_36_16
mv logs/datalog* logs/exp_36_16/
mv logs/properties* logs/exp_36_16/
mv logs/screenshot* logs/exp_36_16/
./roborobo -l config/config_36_32.properties
mkdir logs/exp_36_32
mv logs/datalog* logs/exp_36_32/
mv logs/properties* logs/exp_36_32/
mv logs/screenshot* logs/exp_36_32/
./roborobo -l config/config_36_64.properties
mkdir logs/exp_36_64
mv logs/datalog* logs/exp_36_64/
mv logs/properties* logs/exp_36_64/
mv logs/screenshot* logs/exp_36_64/
./roborobo -l config/config_37_16.properties
mkdir logs/exp_37_16
mv logs/datalog* logs/exp_37_16/
mv logs/properties* logs/exp_37_16/
mv logs/screenshot* logs/exp_37_16/
./roborobo -l config/config_37_32.properties
mkdir logs/exp_37_32
mv logs/datalog* logs/exp_37_32/
mv logs/properties* logs/exp_37_32/
mv logs/screenshot* logs/exp_37_32/
./roborobo -l config/config_37_64.properties
mkdir logs/exp_37_64
mv logs/datalog* logs/exp_37_64/
mv logs/properties* logs/exp_37_64/
mv logs/screenshot* logs/exp_37_64/
./roborobo -l config/config_38_16.properties
mkdir logs/exp_38_16
mv logs/datalog* logs/exp_38_16/
mv logs/properties* logs/exp_38_16/
mv logs/screenshot* logs/exp_38_16/
./roborobo -l config/config_38_32.properties
mkdir logs/exp_38_32
mv logs/datalog* logs/exp_38_32/
mv logs/properties* logs/exp_38_32/
mv logs/screenshot* logs/exp_38_32/
./roborobo -l config/config_38_64.properties
mkdir logs/exp_38_64
mv logs/datalog* logs/exp_38_64/
mv logs/properties* logs/exp_38_64/
mv logs/screenshot* logs/exp_38_64/
./roborobo -l config/config_39_16.properties
mkdir logs/exp_39_16
mv logs/datalog* logs/exp_39_16/
mv logs/properties* logs/exp_39_16/
mv logs/screenshot* logs/exp_39_16/
./roborobo -l config/config_39_32.properties
mkdir logs/exp_39_32
mv logs/datalog* logs/exp_39_32/
mv logs/properties* logs/exp_39_32/
mv logs/screenshot* logs/exp_39_32/
./roborobo -l config/config_39_64.properties
mkdir logs/exp_39_64
mv logs/datalog* logs/exp_39_64/
mv logs/properties* logs/exp_39_64/
mv logs/screenshot* logs/exp_39_64/
./roborobo -l config/config_40_16.properties
mkdir logs/exp_40_16
mv logs/datalog* logs/exp_40_16/
mv logs/properties* logs/exp_40_16/
mv logs/screenshot* logs/exp_40_16/
./roborobo -l config/config_40_32.properties
mkdir logs/exp_40_32
mv logs/datalog* logs/exp_40_32/
mv logs/properties* logs/exp_40_32/
mv logs/screenshot* logs/exp_40_32/
./roborobo -l config/config_40_64.properties
mkdir logs/exp_40_64
mv logs/datalog* logs/exp_40_64/
mv logs/properties* logs/exp_40_64/
mv logs/screenshot* logs/exp_40_64/
./roborobo -l config/config_41_16.properties
mkdir logs/exp_41_16
mv logs/datalog* logs/exp_41_16/
mv logs/properties* logs/exp_41_16/
mv logs/screenshot* logs/exp_41_16/
./roborobo -l config/config_41_32.properties
mkdir logs/exp_41_32
mv logs/datalog* logs/exp_41_32/
mv logs/properties* logs/exp_41_32/
mv logs/screenshot* logs/exp_41_32/
./roborobo -l config/config_41_64.properties
mkdir logs/exp_41_64
mv logs/datalog* logs/exp_41_64/
mv logs/properties* logs/exp_41_64/
mv logs/screenshot* logs/exp_41_64/
./roborobo -l config/config_42_16.properties
mkdir logs/exp_42_16
mv logs/datalog* logs/exp_42_16/
mv logs/properties* logs/exp_42_16/
mv logs/screenshot* logs/exp_42_16/
./roborobo -l config/config_42_32.properties
mkdir logs/exp_42_32
mv logs/datalog* logs/exp_42_32/
mv logs/properties* logs/exp_42_32/
mv logs/screenshot* logs/exp_42_32/
./roborobo -l config/config_42_64.properties
mkdir logs/exp_42_64
mv logs/datalog* logs/exp_42_64/
mv logs/properties* logs/exp_42_64/
mv logs/screenshot* logs/exp_42_64/
./roborobo -l config/config_43_16.properties
mkdir logs/exp_43_16
mv logs/datalog* logs/exp_43_16/
mv logs/properties* logs/exp_43_16/
mv logs/screenshot* logs/exp_43_16/
./roborobo -l config/config_43_32.properties
mkdir logs/exp_43_32
mv logs/datalog* logs/exp_43_32/
mv logs/properties* logs/exp_43_32/
mv logs/screenshot* logs/exp_43_32/
./roborobo -l config/config_43_64.properties
mkdir logs/exp_43_64
mv logs/datalog* logs/exp_43_64/
mv logs/properties* logs/exp_43_64/
mv logs/screenshot* logs/exp_43_64/
./roborobo -l config/config_44_16.properties
mkdir logs/exp_44_16
mv logs/datalog* logs/exp_44_16/
mv logs/properties* logs/exp_44_16/
mv logs/screenshot* logs/exp_44_16/
./roborobo -l config/config_44_32.properties
mkdir logs/exp_44_32
mv logs/datalog* logs/exp_44_32/
mv logs/properties* logs/exp_44_32/
mv logs/screenshot* logs/exp_44_32/
./roborobo -l config/config_44_64.properties
mkdir logs/exp_44_64
mv logs/datalog* logs/exp_44_64/
mv logs/properties* logs/exp_44_64/
mv logs/screenshot* logs/exp_44_64/
./roborobo -l config/config_45_16.properties
mkdir logs/exp_45_16
mv logs/datalog* logs/exp_45_16/
mv logs/properties* logs/exp_45_16/
mv logs/screenshot* logs/exp_45_16/
./roborobo -l config/config_45_32.properties
mkdir logs/exp_45_32
mv logs/datalog* logs/exp_45_32/
mv logs/properties* logs/exp_45_32/
mv logs/screenshot* logs/exp_45_32/
./roborobo -l config/config_45_64.properties
mkdir logs/exp_45_64
mv logs/datalog* logs/exp_45_64/
mv logs/properties* logs/exp_45_64/
mv logs/screenshot* logs/exp_45_64/
./roborobo -l config/config_46_16.properties
mkdir logs/exp_46_16
mv logs/datalog* logs/exp_46_16/
mv logs/properties* logs/exp_46_16/
mv logs/screenshot* logs/exp_46_16/
./roborobo -l config/config_46_32.properties
mkdir logs/exp_46_32
mv logs/datalog* logs/exp_46_32/
mv logs/properties* logs/exp_46_32/
mv logs/screenshot* logs/exp_46_32/
./roborobo -l config/config_46_64.properties
mkdir logs/exp_46_64
mv logs/datalog* logs/exp_46_64/
mv logs/properties* logs/exp_46_64/
mv logs/screenshot* logs/exp_46_64/
./roborobo -l config/config_47_16.properties
mkdir logs/exp_47_16
mv logs/datalog* logs/exp_47_16/
mv logs/properties* logs/exp_47_16/
mv logs/screenshot* logs/exp_47_16/
./roborobo -l config/config_47_32.properties
mkdir logs/exp_47_32
mv logs/datalog* logs/exp_47_32/
mv logs/properties* logs/exp_47_32/
mv logs/screenshot* logs/exp_47_32/
./roborobo -l config/config_47_64.properties
mkdir logs/exp_47_64
mv logs/datalog* logs/exp_47_64/
mv logs/properties* logs/exp_47_64/
mv logs/screenshot* logs/exp_47_64/
./roborobo -l config/config_48_16.properties
mkdir logs/exp_48_16
mv logs/datalog* logs/exp_48_16/
mv logs/properties* logs/exp_48_16/
mv logs/screenshot* logs/exp_48_16/
./roborobo -l config/config_48_32.properties
mkdir logs/exp_48_32
mv logs/datalog* logs/exp_48_32/
mv logs/properties* logs/exp_48_32/
mv logs/screenshot* logs/exp_48_32/
./roborobo -l config/config_48_64.properties
mkdir logs/exp_48_64
mv logs/datalog* logs/exp_48_64/
mv logs/properties* logs/exp_48_64/
mv logs/screenshot* logs/exp_48_64/
./roborobo -l config/config_49_16.properties
mkdir logs/exp_49_16
mv logs/datalog* logs/exp_49_16/
mv logs/properties* logs/exp_49_16/
mv logs/screenshot* logs/exp_49_16/
./roborobo -l config/config_49_32.properties
mkdir logs/exp_49_32
mv logs/datalog* logs/exp_49_32/
mv logs/properties* logs/exp_49_32/
mv logs/screenshot* logs/exp_49_32/
./roborobo -l config/config_49_64.properties
mkdir logs/exp_49_64
mv logs/datalog* logs/exp_49_64/
mv logs/properties* logs/exp_49_64/
mv logs/screenshot* logs/exp_49_64/
./roborobo -l config/config_50_16.properties
mkdir logs/exp_50_16
mv logs/datalog* logs/exp_50_16/
mv logs/properties* logs/exp_50_16/
mv logs/screenshot* logs/exp_50_16/
./roborobo -l config/config_50_32.properties
mkdir logs/exp_50_32
mv logs/datalog* logs/exp_50_32/
mv logs/properties* logs/exp_50_32/
mv logs/screenshot* logs/exp_50_32/
./roborobo -l config/config_50_64.properties
mkdir logs/exp_50_64
mv logs/datalog* logs/exp_50_64/
mv logs/properties* logs/exp_50_64/
mv logs/screenshot* logs/exp_50_64/
./roborobo -l config/config_51_16.properties
mkdir logs/exp_51_16
mv logs/datalog* logs/exp_51_16/
mv logs/properties* logs/exp_51_16/
mv logs/screenshot* logs/exp_51_16/
./roborobo -l config/config_51_32.properties
mkdir logs/exp_51_32
mv logs/datalog* logs/exp_51_32/
mv logs/properties* logs/exp_51_32/
mv logs/screenshot* logs/exp_51_32/
./roborobo -l config/config_51_64.properties
mkdir logs/exp_51_64
mv logs/datalog* logs/exp_51_64/
mv logs/properties* logs/exp_51_64/
mv logs/screenshot* logs/exp_51_64/
./roborobo -l config/config_52_16.properties
mkdir logs/exp_52_16
mv logs/datalog* logs/exp_52_16/
mv logs/properties* logs/exp_52_16/
mv logs/screenshot* logs/exp_52_16/
./roborobo -l config/config_52_32.properties
mkdir logs/exp_52_32
mv logs/datalog* logs/exp_52_32/
mv logs/properties* logs/exp_52_32/
mv logs/screenshot* logs/exp_52_32/
./roborobo -l config/config_52_64.properties
mkdir logs/exp_52_64
mv logs/datalog* logs/exp_52_64/
mv logs/properties* logs/exp_52_64/
mv logs/screenshot* logs/exp_52_64/
./roborobo -l config/config_53_16.properties
mkdir logs/exp_53_16
mv logs/datalog* logs/exp_53_16/
mv logs/properties* logs/exp_53_16/
mv logs/screenshot* logs/exp_53_16/
./roborobo -l config/config_53_32.properties
mkdir logs/exp_53_32
mv logs/datalog* logs/exp_53_32/
mv logs/properties* logs/exp_53_32/
mv logs/screenshot* logs/exp_53_32/
./roborobo -l config/config_53_64.properties
mkdir logs/exp_53_64
mv logs/datalog* logs/exp_53_64/
mv logs/properties* logs/exp_53_64/
mv logs/screenshot* logs/exp_53_64/
./roborobo -l config/config_54_16.properties
mkdir logs/exp_54_16
mv logs/datalog* logs/exp_54_16/
mv logs/properties* logs/exp_54_16/
mv logs/screenshot* logs/exp_54_16/
./roborobo -l config/config_54_32.properties
mkdir logs/exp_54_32
mv logs/datalog* logs/exp_54_32/
mv logs/properties* logs/exp_54_32/
mv logs/screenshot* logs/exp_54_32/
./roborobo -l config/config_54_64.properties
mkdir logs/exp_54_64
mv logs/datalog* logs/exp_54_64/
mv logs/properties* logs/exp_54_64/
mv logs/screenshot* logs/exp_54_64/
./roborobo -l config/config_55_16.properties
mkdir logs/exp_55_16
mv logs/datalog* logs/exp_55_16/
mv logs/properties* logs/exp_55_16/
mv logs/screenshot* logs/exp_55_16/
./roborobo -l config/config_55_32.properties
mkdir logs/exp_55_32
mv logs/datalog* logs/exp_55_32/
mv logs/properties* logs/exp_55_32/
mv logs/screenshot* logs/exp_55_32/
./roborobo -l config/config_55_64.properties
mkdir logs/exp_55_64
mv logs/datalog* logs/exp_55_64/
mv logs/properties* logs/exp_55_64/
mv logs/screenshot* logs/exp_55_64/
./roborobo -l config/config_56_16.properties
mkdir logs/exp_56_16
mv logs/datalog* logs/exp_56_16/
mv logs/properties* logs/exp_56_16/
mv logs/screenshot* logs/exp_56_16/
./roborobo -l config/config_56_32.properties
mkdir logs/exp_56_32
mv logs/datalog* logs/exp_56_32/
mv logs/properties* logs/exp_56_32/
mv logs/screenshot* logs/exp_56_32/
./roborobo -l config/config_56_64.properties
mkdir logs/exp_56_64
mv logs/datalog* logs/exp_56_64/
mv logs/properties* logs/exp_56_64/
mv logs/screenshot* logs/exp_56_64/
./roborobo -l config/config_57_16.properties
mkdir logs/exp_57_16
mv logs/datalog* logs/exp_57_16/
mv logs/properties* logs/exp_57_16/
mv logs/screenshot* logs/exp_57_16/
./roborobo -l config/config_57_32.properties
mkdir logs/exp_57_32
mv logs/datalog* logs/exp_57_32/
mv logs/properties* logs/exp_57_32/
mv logs/screenshot* logs/exp_57_32/
./roborobo -l config/config_57_64.properties
mkdir logs/exp_57_64
mv logs/datalog* logs/exp_57_64/
mv logs/properties* logs/exp_57_64/
mv logs/screenshot* logs/exp_57_64/
./roborobo -l config/config_58_16.properties
mkdir logs/exp_58_16
mv logs/datalog* logs/exp_58_16/
mv logs/properties* logs/exp_58_16/
mv logs/screenshot* logs/exp_58_16/
./roborobo -l config/config_58_32.properties
mkdir logs/exp_58_32
mv logs/datalog* logs/exp_58_32/
mv logs/properties* logs/exp_58_32/
mv logs/screenshot* logs/exp_58_32/
./roborobo -l config/config_58_64.properties
mkdir logs/exp_58_64
mv logs/datalog* logs/exp_58_64/
mv logs/properties* logs/exp_58_64/
mv logs/screenshot* logs/exp_58_64/
./roborobo -l config/config_59_16.properties
mkdir logs/exp_59_16
mv logs/datalog* logs/exp_59_16/
mv logs/properties* logs/exp_59_16/
mv logs/screenshot* logs/exp_59_16/
./roborobo -l config/config_59_32.properties
mkdir logs/exp_59_32
mv logs/datalog* logs/exp_59_32/
mv logs/properties* logs/exp_59_32/
mv logs/screenshot* logs/exp_59_32/
./roborobo -l config/config_59_64.properties
mkdir logs/exp_59_64
mv logs/datalog* logs/exp_59_64/
mv logs/properties* logs/exp_59_64/
mv logs/screenshot* logs/exp_59_64/
./roborobo -l config/config_60_16.properties
mkdir logs/exp_60_16
mv logs/datalog* logs/exp_60_16/
mv logs/properties* logs/exp_60_16/
mv logs/screenshot* logs/exp_60_16/
./roborobo -l config/config_60_32.properties
mkdir logs/exp_60_32
mv logs/datalog* logs/exp_60_32/
mv logs/properties* logs/exp_60_32/
mv logs/screenshot* logs/exp_60_32/
./roborobo -l config/config_60_64.properties
mkdir logs/exp_60_64
mv logs/datalog* logs/exp_60_64/
mv logs/properties* logs/exp_60_64/
mv logs/screenshot* logs/exp_60_64/
./roborobo -l config/config_61_16.properties
mkdir logs/exp_61_16
mv logs/datalog* logs/exp_61_16/
mv logs/properties* logs/exp_61_16/
mv logs/screenshot* logs/exp_61_16/
./roborobo -l config/config_61_32.properties
mkdir logs/exp_61_32
mv logs/datalog* logs/exp_61_32/
mv logs/properties* logs/exp_61_32/
mv logs/screenshot* logs/exp_61_32/
./roborobo -l config/config_61_64.properties
mkdir logs/exp_61_64
mv logs/datalog* logs/exp_61_64/
mv logs/properties* logs/exp_61_64/
mv logs/screenshot* logs/exp_61_64/
./roborobo -l config/config_62_16.properties
mkdir logs/exp_62_16
mv logs/datalog* logs/exp_62_16/
mv logs/properties* logs/exp_62_16/
mv logs/screenshot* logs/exp_62_16/
./roborobo -l config/config_62_32.properties
mkdir logs/exp_62_32
mv logs/datalog* logs/exp_62_32/
mv logs/properties* logs/exp_62_32/
mv logs/screenshot* logs/exp_62_32/
./roborobo -l config/config_62_64.properties
mkdir logs/exp_62_64
mv logs/datalog* logs/exp_62_64/
mv logs/properties* logs/exp_62_64/
mv logs/screenshot* logs/exp_62_64/
./roborobo -l config/config_63_16.properties
mkdir logs/exp_63_16
mv logs/datalog* logs/exp_63_16/
mv logs/properties* logs/exp_63_16/
mv logs/screenshot* logs/exp_63_16/
./roborobo -l config/config_63_32.properties
mkdir logs/exp_63_32
mv logs/datalog* logs/exp_63_32/
mv logs/properties* logs/exp_63_32/
mv logs/screenshot* logs/exp_63_32/
./roborobo -l config/config_63_64.properties
mkdir logs/exp_63_64
mv logs/datalog* logs/exp_63_64/
mv logs/properties* logs/exp_63_64/
mv logs/screenshot* logs/exp_63_64/
./roborobo -l config/config_64_16.properties
mkdir logs/exp_64_16
mv logs/datalog* logs/exp_64_16/
mv logs/properties* logs/exp_64_16/
mv logs/screenshot* logs/exp_64_16/
./roborobo -l config/config_64_32.properties
mkdir logs/exp_64_32
mv logs/datalog* logs/exp_64_32/
mv logs/properties* logs/exp_64_32/
mv logs/screenshot* logs/exp_64_32/
./roborobo -l config/config_64_64.properties
mkdir logs/exp_64_64
mv logs/datalog* logs/exp_64_64/
mv logs/properties* logs/exp_64_64/
mv logs/screenshot* logs/exp_64_64/
./roborobo -l config/config_65_16.properties
mkdir logs/exp_65_16
mv logs/datalog* logs/exp_65_16/
mv logs/properties* logs/exp_65_16/
mv logs/screenshot* logs/exp_65_16/
./roborobo -l config/config_65_32.properties
mkdir logs/exp_65_32
mv logs/datalog* logs/exp_65_32/
mv logs/properties* logs/exp_65_32/
mv logs/screenshot* logs/exp_65_32/
./roborobo -l config/config_65_64.properties
mkdir logs/exp_65_64
mv logs/datalog* logs/exp_65_64/
mv logs/properties* logs/exp_65_64/
mv logs/screenshot* logs/exp_65_64/
./roborobo -l config/config_66_16.properties
mkdir logs/exp_66_16
mv logs/datalog* logs/exp_66_16/
mv logs/properties* logs/exp_66_16/
mv logs/screenshot* logs/exp_66_16/
./roborobo -l config/config_66_32.properties
mkdir logs/exp_66_32
mv logs/datalog* logs/exp_66_32/
mv logs/properties* logs/exp_66_32/
mv logs/screenshot* logs/exp_66_32/
./roborobo -l config/config_66_64.properties
mkdir logs/exp_66_64
mv logs/datalog* logs/exp_66_64/
mv logs/properties* logs/exp_66_64/
mv logs/screenshot* logs/exp_66_64/
./roborobo -l config/config_67_16.properties
mkdir logs/exp_67_16
mv logs/datalog* logs/exp_67_16/
mv logs/properties* logs/exp_67_16/
mv logs/screenshot* logs/exp_67_16/
./roborobo -l config/config_67_32.properties
mkdir logs/exp_67_32
mv logs/datalog* logs/exp_67_32/
mv logs/properties* logs/exp_67_32/
mv logs/screenshot* logs/exp_67_32/
./roborobo -l config/config_67_64.properties
mkdir logs/exp_67_64
mv logs/datalog* logs/exp_67_64/
mv logs/properties* logs/exp_67_64/
mv logs/screenshot* logs/exp_67_64/
./roborobo -l config/config_68_16.properties
mkdir logs/exp_68_16
mv logs/datalog* logs/exp_68_16/
mv logs/properties* logs/exp_68_16/
mv logs/screenshot* logs/exp_68_16/
./roborobo -l config/config_68_32.properties
mkdir logs/exp_68_32
mv logs/datalog* logs/exp_68_32/
mv logs/properties* logs/exp_68_32/
mv logs/screenshot* logs/exp_68_32/
./roborobo -l config/config_68_64.properties
mkdir logs/exp_68_64
mv logs/datalog* logs/exp_68_64/
mv logs/properties* logs/exp_68_64/
mv logs/screenshot* logs/exp_68_64/
./roborobo -l config/config_69_16.properties
mkdir logs/exp_69_16
mv logs/datalog* logs/exp_69_16/
mv logs/properties* logs/exp_69_16/
mv logs/screenshot* logs/exp_69_16/
./roborobo -l config/config_69_32.properties
mkdir logs/exp_69_32
mv logs/datalog* logs/exp_69_32/
mv logs/properties* logs/exp_69_32/
mv logs/screenshot* logs/exp_69_32/
./roborobo -l config/config_69_64.properties
mkdir logs/exp_69_64
mv logs/datalog* logs/exp_69_64/
mv logs/properties* logs/exp_69_64/
mv logs/screenshot* logs/exp_69_64/
./roborobo -l config/config_70_16.properties
mkdir logs/exp_70_16
mv logs/datalog* logs/exp_70_16/
mv logs/properties* logs/exp_70_16/
mv logs/screenshot* logs/exp_70_16/
./roborobo -l config/config_70_32.properties
mkdir logs/exp_70_32
mv logs/datalog* logs/exp_70_32/
mv logs/properties* logs/exp_70_32/
mv logs/screenshot* logs/exp_70_32/
./roborobo -l config/config_70_64.properties
mkdir logs/exp_70_64
mv logs/datalog* logs/exp_70_64/
mv logs/properties* logs/exp_70_64/
mv logs/screenshot* logs/exp_70_64/
./roborobo -l config/config_71_16.properties
mkdir logs/exp_71_16
mv logs/datalog* logs/exp_71_16/
mv logs/properties* logs/exp_71_16/
mv logs/screenshot* logs/exp_71_16/
./roborobo -l config/config_71_32.properties
mkdir logs/exp_71_32
mv logs/datalog* logs/exp_71_32/
mv logs/properties* logs/exp_71_32/
mv logs/screenshot* logs/exp_71_32/
./roborobo -l config/config_71_64.properties
mkdir logs/exp_71_64
mv logs/datalog* logs/exp_71_64/
mv logs/properties* logs/exp_71_64/
mv logs/screenshot* logs/exp_71_64/
./roborobo -l config/config_72_16.properties
mkdir logs/exp_72_16
mv logs/datalog* logs/exp_72_16/
mv logs/properties* logs/exp_72_16/
mv logs/screenshot* logs/exp_72_16/
./roborobo -l config/config_72_32.properties
mkdir logs/exp_72_32
mv logs/datalog* logs/exp_72_32/
mv logs/properties* logs/exp_72_32/
mv logs/screenshot* logs/exp_72_32/
./roborobo -l config/config_72_64.properties
mkdir logs/exp_72_64
mv logs/datalog* logs/exp_72_64/
mv logs/properties* logs/exp_72_64/
mv logs/screenshot* logs/exp_72_64/
./roborobo -l config/config_73_16.properties
mkdir logs/exp_73_16
mv logs/datalog* logs/exp_73_16/
mv logs/properties* logs/exp_73_16/
mv logs/screenshot* logs/exp_73_16/
./roborobo -l config/config_73_32.properties
mkdir logs/exp_73_32
mv logs/datalog* logs/exp_73_32/
mv logs/properties* logs/exp_73_32/
mv logs/screenshot* logs/exp_73_32/
./roborobo -l config/config_73_64.properties
mkdir logs/exp_73_64
mv logs/datalog* logs/exp_73_64/
mv logs/properties* logs/exp_73_64/
mv logs/screenshot* logs/exp_73_64/
./roborobo -l config/config_74_16.properties
mkdir logs/exp_74_16
mv logs/datalog* logs/exp_74_16/
mv logs/properties* logs/exp_74_16/
mv logs/screenshot* logs/exp_74_16/
./roborobo -l config/config_74_32.properties
mkdir logs/exp_74_32
mv logs/datalog* logs/exp_74_32/
mv logs/properties* logs/exp_74_32/
mv logs/screenshot* logs/exp_74_32/
./roborobo -l config/config_74_64.properties
mkdir logs/exp_74_64
mv logs/datalog* logs/exp_74_64/
mv logs/properties* logs/exp_74_64/
mv logs/screenshot* logs/exp_74_64/
./roborobo -l config/config_75_16.properties
mkdir logs/exp_75_16
mv logs/datalog* logs/exp_75_16/
mv logs/properties* logs/exp_75_16/
mv logs/screenshot* logs/exp_75_16/
./roborobo -l config/config_75_32.properties
mkdir logs/exp_75_32
mv logs/datalog* logs/exp_75_32/
mv logs/properties* logs/exp_75_32/
mv logs/screenshot* logs/exp_75_32/
./roborobo -l config/config_75_64.properties
mkdir logs/exp_75_64
mv logs/datalog* logs/exp_75_64/
mv logs/properties* logs/exp_75_64/
mv logs/screenshot* logs/exp_75_64/
./roborobo -l config/config_76_16.properties
mkdir logs/exp_76_16
mv logs/datalog* logs/exp_76_16/
mv logs/properties* logs/exp_76_16/
mv logs/screenshot* logs/exp_76_16/
./roborobo -l config/config_76_32.properties
mkdir logs/exp_76_32
mv logs/datalog* logs/exp_76_32/
mv logs/properties* logs/exp_76_32/
mv logs/screenshot* logs/exp_76_32/
./roborobo -l config/config_76_64.properties
mkdir logs/exp_76_64
mv logs/datalog* logs/exp_76_64/
mv logs/properties* logs/exp_76_64/
mv logs/screenshot* logs/exp_76_64/
./roborobo -l config/config_77_16.properties
mkdir logs/exp_77_16
mv logs/datalog* logs/exp_77_16/
mv logs/properties* logs/exp_77_16/
mv logs/screenshot* logs/exp_77_16/
./roborobo -l config/config_77_32.properties
mkdir logs/exp_77_32
mv logs/datalog* logs/exp_77_32/
mv logs/properties* logs/exp_77_32/
mv logs/screenshot* logs/exp_77_32/
./roborobo -l config/config_77_64.properties
mkdir logs/exp_77_64
mv logs/datalog* logs/exp_77_64/
mv logs/properties* logs/exp_77_64/
mv logs/screenshot* logs/exp_77_64/
./roborobo -l config/config_78_16.properties
mkdir logs/exp_78_16
mv logs/datalog* logs/exp_78_16/
mv logs/properties* logs/exp_78_16/
mv logs/screenshot* logs/exp_78_16/
./roborobo -l config/config_78_32.properties
mkdir logs/exp_78_32
mv logs/datalog* logs/exp_78_32/
mv logs/properties* logs/exp_78_32/
mv logs/screenshot* logs/exp_78_32/
./roborobo -l config/config_78_64.properties
mkdir logs/exp_78_64
mv logs/datalog* logs/exp_78_64/
mv logs/properties* logs/exp_78_64/
mv logs/screenshot* logs/exp_78_64/
./roborobo -l config/config_79_16.properties
mkdir logs/exp_79_16
mv logs/datalog* logs/exp_79_16/
mv logs/properties* logs/exp_79_16/
mv logs/screenshot* logs/exp_79_16/
./roborobo -l config/config_79_32.properties
mkdir logs/exp_79_32
mv logs/datalog* logs/exp_79_32/
mv logs/properties* logs/exp_79_32/
mv logs/screenshot* logs/exp_79_32/
./roborobo -l config/config_79_64.properties
mkdir logs/exp_79_64
mv logs/datalog* logs/exp_79_64/
mv logs/properties* logs/exp_79_64/
mv logs/screenshot* logs/exp_79_64/
./roborobo -l config/config_80_16.properties
mkdir logs/exp_80_16
mv logs/datalog* logs/exp_80_16/
mv logs/properties* logs/exp_80_16/
mv logs/screenshot* logs/exp_80_16/
./roborobo -l config/config_80_32.properties
mkdir logs/exp_80_32
mv logs/datalog* logs/exp_80_32/
mv logs/properties* logs/exp_80_32/
mv logs/screenshot* logs/exp_80_32/
./roborobo -l config/config_80_64.properties
mkdir logs/exp_80_64
mv logs/datalog* logs/exp_80_64/
mv logs/properties* logs/exp_80_64/
mv logs/screenshot* logs/exp_80_64/
