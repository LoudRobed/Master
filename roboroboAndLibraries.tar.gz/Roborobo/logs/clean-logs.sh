rm -f datalog_*.txt
rm -f properties_*.txt
rm -f screenshot_*.bmp
rm -f trajectory_*.bmp
rm -f extract.dat*
rm -f *.eps
rm -f log.txt
rm -f extract*.dat
