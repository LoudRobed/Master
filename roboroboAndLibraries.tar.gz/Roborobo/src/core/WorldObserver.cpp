/*
 *  WorldObserver.cpp
 *  roborobo-online
 *
 *  Created by Nicolas on 20/03/09.
 *  Copyright 2009 __MyCompanyName__. All rights reserved.
 *
 */

#include "Observers/WorldObserver.h"

#include "World/World.h"


WorldObserver::WorldObserver( World *__world ) 
{
	_world = __world;
}

WorldObserver::~WorldObserver()
{
	// nothing to do.
}

void WorldObserver::reset()
{
	// nothing to do.
}

void WorldObserver::step()
{
	// nothing to do.
}


