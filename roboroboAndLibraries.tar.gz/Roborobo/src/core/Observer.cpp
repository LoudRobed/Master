/*
 *  Observer.cpp
 *  roborobo-online
 *
 *  Created by Nicolas on 20/03/09.
 *  Copyright 2009 __MyCompanyName__. All rights reserved.
 *
 */

#include "Observers/Observer.h"

Observer::Observer( )
{
	// nothing to do.
}

Observer::~Observer()
{
	// nothing to do.
}

void Observer::reset()
{
	// nothing to do.
}

void Observer::step()
{
	// nothing to do.
}

