/*
 *  WorldModel.cpp
 *  roborobo-online
 *
 *  Created by Nicolas on 20/03/09.
 *  Copyright 2009 __MyCompanyName__. All rights reserved.
 *
 */

#include "WorldModels/WorldModel.h"

WorldModel::WorldModel()
{
}

WorldModel::~WorldModel()
{
}

