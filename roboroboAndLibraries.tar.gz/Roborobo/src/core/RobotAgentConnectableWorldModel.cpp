/*
 *  RobotAgentConnectableWorldModel.cpp
 *
 *  Created by Nicolas on 20/03/09.
 *  Copyright 2009 __MyCompanyName__. All rights reserved.
 *
 */

#include "WorldModels/RobotAgentConnectableWorldModel.h"

#include "World/World.h"

RobotAgentConnectableWorldModel::RobotAgentConnectableWorldModel():
RobotAgentWorldModel()
{
	joinedOrganism = false;
}

RobotAgentConnectableWorldModel::~RobotAgentConnectableWorldModel()
{
	//Nothing to do
}

