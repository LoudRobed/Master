#ifndef GLOBALCONFIGURATIONLOADER_H
#define GLOBALCONFIGURATIONLOADER_H

#include "Config/ConfigurationLoader.h"

extern ConfigurationLoader *gConfigurationLoader;

#endif
